package com.example.demo;

public enum Level {
    INPUT, ALGORITHM, ERROR, CLUE;
}
