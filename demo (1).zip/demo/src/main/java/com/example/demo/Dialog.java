package com.example.demo;

public interface Dialog {
    public void setReader(Reader log);
    public void setObserver(Observer obs);
}
